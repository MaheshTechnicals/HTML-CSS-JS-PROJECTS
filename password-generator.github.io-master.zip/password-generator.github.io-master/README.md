# password-generator

Create random **passwords** using the password **generator** tool.

Demo: https://codepen.io/dev_loop/full/vYYxvbz

![Tool](https://github.com/devloop01/password-generator/blob/master/img/Screenshot%20from%202020-01-01%2003-54-29.png)

After selecting the desired options for the password, click **generate** to generate 

a new password with selected options.

![password](https://github.com/devloop01/password-generator/blob/master/img/Screenshot%20from%202020-01-01%2003-54-50.png)

Then click the password area to copy the password to clipboard.
